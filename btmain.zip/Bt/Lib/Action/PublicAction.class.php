<?php
	class PublicAction extends Action{
		Public function verify(){
			ob_clean();
        	import('ORG.Util.Image');
        	Image::buildImageVerify();
    	}
	}