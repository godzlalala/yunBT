<?php
	$dir=dirname(__FILE__);
	define('APP_PATH','./Bt/');
	define('APP_NAME','Index');
	define('APP_DEBUG',True);
	define("DIR",$dir);
	define("DO_SIZE",10);//下载最大文件限制  
	require './ThinkPHP/ThinkPHP.php';


?>
